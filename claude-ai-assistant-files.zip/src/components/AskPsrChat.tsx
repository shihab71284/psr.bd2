"use client";

import { useEffect, useRef, useState } from "react";
import { MessageCircle, X, Send, Loader2 } from "lucide-react";

type Msg = { role: "user" | "assistant"; content: string };

const SUGGESTIONS = [
  "করমুক্ত আয়সীমা কত?",
  "নিট সম্পদে সারচার্জ কখন লাগে?",
  "আপিল কতদিনের মধ্যে করতে হয়?",
];

export default function AskPsrChat() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading, open]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || loading) return;

    const next: Msg[] = [...messages, { role: "user", content }];
    setMessages(next);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        // Send only the most recent turns to keep requests small.
        body: JSON.stringify({ messages: next.slice(-12) }),
      });
      const data = await res.json().catch(() => ({}));
      const reply = res.ok
        ? data.reply
        : data.error || "দুঃখিত, কিছু একটা সমস্যা হয়েছে।";
      setMessages([...next, { role: "assistant", content: reply }]);
    } catch {
      setMessages([
        ...next,
        { role: "assistant", content: "নেটওয়ার্ক সমস্যা। আবার চেষ্টা করুন।" },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      {open && (
        <div className="fixed bottom-20 right-4 z-50 flex h-[32rem] max-h-[calc(100vh-7rem)] w-[22rem] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
          <div className="flex items-center justify-between bg-emerald-700 px-4 py-3 text-white">
            <div>
              <p className="text-sm font-bold">psr.bd সহকারী</p>
              <p className="text-[11px] text-emerald-100">কর ও ভ্যাট বিষয়ক এআই সহায়তা</p>
            </div>
            <button
              onClick={() => setOpen(false)}
              aria-label="বন্ধ করুন"
              className="rounded-lg p-1 hover:bg-emerald-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto bg-slate-50 p-3 text-sm">
            {messages.length === 0 && (
              <div className="space-y-2">
                <p className="text-slate-600">
                  আয়কর, ভ্যাট ও অডিট ঝুঁকি নিয়ে প্রশ্ন করুন।
                </p>
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="block w-full rounded-xl border border-emerald-200 bg-white px-3 py-2 text-left text-emerald-800 hover:bg-emerald-50"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            {messages.map((m, i) => (
              <div
                key={i}
                className={m.role === "user" ? "flex justify-end" : "flex justify-start"}
              >
                <div
                  className={
                    "max-w-[85%] whitespace-pre-wrap rounded-2xl px-3 py-2 leading-relaxed " +
                    (m.role === "user"
                      ? "bg-emerald-700 text-white"
                      : "border border-slate-200 bg-white text-slate-800")
                  }
                >
                  {m.content}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex items-center gap-2 text-slate-500">
                <Loader2 className="h-4 w-4 animate-spin" /> ভাবছি…
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          <p className="border-t border-slate-200 bg-white px-3 pt-2 text-[10px] text-slate-400">
            এটি নির্দেশনামূলক তথ্য, আইনি পরামর্শ নয়। দাখিলের আগে এনবিআরের সর্বশেষ বিজ্ঞপ্তি যাচাই করুন।
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex gap-2 bg-white p-3 pt-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              maxLength={2000}
              placeholder="আপনার প্রশ্ন লিখুন…"
              className="min-w-0 flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-emerald-600"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              aria-label="পাঠান"
              className="rounded-xl bg-emerald-700 px-3 text-white disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}

      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="এআই সহকারী খুলুন"
        className="fixed bottom-4 right-4 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-700 text-white shadow-lg hover:bg-emerald-800"
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>
    </>
  );
}

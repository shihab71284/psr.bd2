import { z } from "zod";
import { askClaude, AiNotConfiguredError } from "@/lib/claude";
import { buildChatSystemPrompt } from "@/lib/aiPrompt";

export const dynamic = "force-dynamic";

const Body = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().trim().min(1).max(2000),
      })
    )
    .min(1)
    .max(20),
});

// --- Basic abuse / cost protection (in-memory, best effort) -----------------
// This endpoint is public, so every request spends API credit. These limits are
// per server instance; on serverless hosts use a shared store (Redis/Upstash)
// if you need strict limits.
const PER_IP_LIMIT = 12; // requests
const PER_IP_WINDOW_MS = 10 * 60 * 1000; // per 10 minutes
const DAILY_LIMIT = Number(process.env.AI_DAILY_LIMIT || 500); // all users

const ipHits = new Map<string, { count: number; resetAt: number }>();
let daily = { day: "", count: 0 };

function allow(ip: string): "ok" | "ip" | "daily" {
  const now = Date.now();
  const today = new Date(now).toISOString().slice(0, 10);
  if (daily.day !== today) daily = { day: today, count: 0 };
  if (daily.count >= DAILY_LIMIT) return "daily";

  const hit = ipHits.get(ip);
  if (!hit || hit.resetAt < now) {
    ipHits.set(ip, { count: 1, resetAt: now + PER_IP_WINDOW_MS });
  } else if (hit.count >= PER_IP_LIMIT) {
    return "ip";
  } else {
    hit.count += 1;
  }

  // Keep the map from growing forever.
  if (ipHits.size > 5000) {
    for (const [key, value] of ipHits) if (value.resetAt < now) ipHits.delete(key);
  }

  daily.count += 1;
  return "ok";
}

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";

  let parsed;
  try {
    parsed = Body.safeParse(await req.json());
  } catch {
    return Response.json({ error: "অবৈধ অনুরোধ।" }, { status: 400 });
  }
  if (!parsed.success) {
    return Response.json({ error: "অবৈধ অনুরোধ।" }, { status: 400 });
  }

  const { messages } = parsed.data;
  if (messages[messages.length - 1].role !== "user") {
    return Response.json({ error: "অবৈধ অনুরোধ।" }, { status: 400 });
  }

  const verdict = allow(ip);
  if (verdict === "ip") {
    return Response.json(
      { error: "অনেক বেশি প্রশ্ন করা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।" },
      { status: 429 }
    );
  }
  if (verdict === "daily") {
    return Response.json(
      { error: "আজকের জন্য সহকারীর সীমা শেষ। আগামীকাল আবার চেষ্টা করুন।" },
      { status: 429 }
    );
  }

  try {
    const reply = await askClaude({
      system: buildChatSystemPrompt(),
      messages,
      maxTokens: 800,
    });
    return Response.json({ reply: reply || "দুঃখিত, উত্তর তৈরি করা যায়নি।" });
  } catch (err) {
    if (err instanceof AiNotConfiguredError) {
      return Response.json(
        { error: "এআই সহকারী এখনো সক্রিয় করা হয়নি।" },
        { status: 503 }
      );
    }
    return Response.json(
      { error: "এআই সহকারী এই মুহূর্তে উত্তর দিতে পারছে না। একটু পরে চেষ্টা করুন।" },
      { status: 502 }
    );
  }
}
